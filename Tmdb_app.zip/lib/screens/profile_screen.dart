import 'package:flutter/material.dart';

class ProfileScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        centerTitle: true,
        title: Padding(
          padding: const EdgeInsets.only(top: 8.0),
          child: Text(
            'MOVIE TRACKER',
            style: Theme.of(context).textTheme.displayLarge,
          ),
        ),
        bottom: PreferredSize(
          preferredSize: Size.fromHeight(2.0),
          child: Divider(thickness: 2, color: Colors.white, height: 2),
        ),
      ),
      body: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: Text(
              'My Watchlist',
              style: TextStyle(fontSize: 22, color: Colors.white),
            ),
          ),
          Expanded(
            child: Center(
              child: Text(
                'No movies added yet.',
                style: TextStyle(color: Colors.white70),
              ),
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: Text(
              'My Rated Movies',
              style: TextStyle(fontSize: 22, color: Colors.white),
            ),
          ),
          Expanded(
            child: Center(
              child: Text(
                'No movies rated yet.',
                style: TextStyle(color: Colors.white70),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
