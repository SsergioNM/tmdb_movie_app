import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';

class PopularScreen extends StatefulWidget {
  @override
  _PopularScreenState createState() => _PopularScreenState();
}

class _PopularScreenState extends State<PopularScreen> {
  List movies = [];
  List tvShows = [];
  final String apiKey = '475db9e83f430ccd9674186105058ef2';

  @override
  void initState() {
    super.initState();
    fetchPopularContent();
  }

  Future<void> fetchPopularContent() async {
    final moviesUrl =
        'https://api.themoviedb.org/3/movie/popular?api_key=$apiKey&language=en-US&page=1';
    final tvUrl =
        'https://api.themoviedb.org/3/tv/popular?api_key=$apiKey&language=en-US&page=1';

    final moviesResponse = await http.get(Uri.parse(moviesUrl));
    final tvResponse = await http.get(Uri.parse(tvUrl));

    if (moviesResponse.statusCode == 200 &&
        tvResponse.statusCode == 200) {
      setState(() {
        movies = json.decode(moviesResponse.body)['results'];
        tvShows = json.decode(tvResponse.body)['results'];
      });
    } else {
      throw Exception('Failed to load content');
    }
  }

  @override
  Widget build(BuildContext context) {
    return ListView(
      children: [
        buildSection('Popular Movies', movies),
        buildSection('Popular TV Shows', tvShows),
      ],
    );
  }

  Widget buildSection(String title, List content) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Padding(
          padding: const EdgeInsets.all(8.0),
          child: Text(
            title,
            style: TextStyle(color: Colors.white, fontSize: 24),
          ),
        ),
        Container(
          height: 200,
          child: ListView.builder(
            scrollDirection: Axis.horizontal,
            itemCount: content.length,
            itemBuilder: (context, index) {
              final item = content[index];
              return Container(
                margin: EdgeInsets.all(8.0),
                width: 120,
                child: Column(
                  children: [
                    Expanded(
                      child: Image.network(
                        'https://image.tmdb.org/t/p/w200${item['poster_path']}',
                        fit: BoxFit.cover,
                      ),
                    ),
                    SizedBox(height: 8),
                    Text(
                      item['title'] ?? item['name'],
                      style: TextStyle(color: Colors.white),
                      overflow: TextOverflow.ellipsis,
                    ),
                  ],
                ),
              );
            },
          ),
        ),
      ],
    );
  }
}
