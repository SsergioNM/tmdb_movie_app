import 'package:flutter/material.dart';
import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';
import 'movie_details_screen.dart'; 

class SearchScreen extends StatefulWidget {
  @override
  _SearchScreenState createState() => _SearchScreenState();
}

class _SearchScreenState extends State<SearchScreen> {
  List searchResults = [];
  List<String> recentSearches = [];
  TextEditingController searchController = TextEditingController();
  final String apiKey = '475db9e83f430ccd9674186105058ef2';


  @override
  void initState() {
    super.initState();
    loadRecentSearches();
  }

  Future<void> loadRecentSearches() async {
    final prefs = await SharedPreferences.getInstance();
    setState(() {
      recentSearches = prefs.getStringList('recentSearches') ?? [];
    });
  }

  Future<void> saveRecentSearch(String query) async {
    final prefs = await SharedPreferences.getInstance();
    if (!recentSearches.contains(query)) {
      recentSearches.insert(0, query);
      if (recentSearches.length > 10) recentSearches.removeLast();
      await prefs.setStringList('recentSearches', recentSearches);
    }
  }

  Future<void> searchContent(String query) async {
    if (query.isEmpty) return;
    await saveRecentSearch(query);
    final response = await http.get(
      Uri.parse('https://api.themoviedb.org/3/search/multi?api_key=$apiKey&query=$query'),
    );

    if (response.statusCode == 200) {
      setState(() {
        searchResults = json.decode(response.body)['results'];
      });
    } else {
      throw Exception('Failed to search content');
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        centerTitle: true,
        title: Text('MOVIE TRACKER', style: Theme.of(context).textTheme.displayLarge),
        bottom: PreferredSize(
          preferredSize: Size.fromHeight(2.0),
          child: Divider(thickness: 2, color: Colors.white, height: 2),
        ),
      ),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: TextField(
              controller: searchController,
              style: TextStyle(color: Colors.white),
              decoration: InputDecoration(
                hintText: 'Search movies, TV shows, or actors...',
                hintStyle: TextStyle(color: Colors.white54),
                filled: true,
                fillColor: Colors.white10,
                border: OutlineInputBorder(borderRadius: BorderRadius.circular(8.0)),
              ),
              onSubmitted: (value) {
                searchContent(value);
              },
            ),
          ),
          SizedBox(height: 8),
          
          if (recentSearches.isNotEmpty)
            SizedBox(
              height: 40,
              child: ListView(
                scrollDirection: Axis.horizontal,
                children: recentSearches.map((search) {
                  return GestureDetector(
                    onTap: () {
                      searchController.text = search;
                      searchContent(search);
                    },
                    child: Container(
                      margin: EdgeInsets.symmetric(horizontal: 4),
                      padding: EdgeInsets.all(8),
                      decoration: BoxDecoration(
                        color: Colors.white10,
                        borderRadius: BorderRadius.circular(8),
                      ),
                      child: Text(search, style: TextStyle(color: Colors.white70)),
                    ),
                  );
                }).toList(),
              ),
            ),
          Expanded(
            child: searchResults.isEmpty
                ? Center(
                    child: Text('No results', style: TextStyle(color: Colors.white70)),
                  )
                : ListView.builder(
                    itemCount: searchResults.length,
                    itemBuilder: (context, index) {
                      final item = searchResults[index];
                      final String title = item['title'] ?? item['name'] ?? 'Unknown';
                      final String mediaType = item['media_type'] ?? 'unknown';

                      return ListTile(
                        leading: item['poster_path'] != null
                            ? Image.network(
                                'https://image.tmdb.org/t/p/w200${item['poster_path']}',
                                fit: BoxFit.cover,
                              )
                            : Icon(Icons.movie, color: Colors.white70, size: 50),
                        title: Text(
                          '$title (${mediaType.toUpperCase()})',
                          style: TextStyle(color: Colors.white),
                        ),
                        onTap: () {
                          
                          Navigator.push(
                            context,
                            MaterialPageRoute(
                              builder: (context) => MovieDetailsScreen(movie: item),
                            ),
                          );
                        },
                      );
                    },
                  ),
          ),
        ],
      ),
    );
  }
}
